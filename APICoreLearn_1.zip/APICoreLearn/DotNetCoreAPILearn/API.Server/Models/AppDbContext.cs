﻿using Microsoft.EntityFrameworkCore;

namespace API.Server.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            :base(options)
        {

        }

        public DbSet<Employee> Employees { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // seed Employee Table
            modelBuilder.Entity<Employee>()
                .HasData(
                new Employee
                {
                    ID = 1,
                    Firstname = "Sivakumar",
                    Lastname = "AR",
                    Email = "abc@gmail.com",
                    Gender = Gender.Male,
                    DepartmentID = 1
                },
                 new Employee
                 {
                     ID = 2,
                     Firstname = "Sutha",
                     Lastname = "V",
                     Email = "xyz@gmail.com",
                     Gender = Gender.Female,
                     DepartmentID = 2
                 });
        }
    }
}
