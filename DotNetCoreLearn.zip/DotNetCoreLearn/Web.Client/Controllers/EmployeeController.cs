﻿using Microsoft.AspNetCore.Mvc;
using Web.Client.Models;

namespace Web.Client.Controllers
{
    public class EmployeeController : Controller
    {
        private IHttpClientFactory _httpClientFactory;
        private readonly ILogger<EmployeeController> _logger;
        public EmployeeController(ILogger<EmployeeController> logger,
        IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
        }
        public async Task<IActionResult> Index()
        {
            HttpClient httpClient = _httpClientFactory.CreateClient();
            httpClient.BaseAddress = new Uri("https://localhost:7278/api/");
            var result = await httpClient.GetFromJsonAsync<IEnumerable<EmployeeViewModel>>("employees");
            return View(result);
        }

        public ActionResult Details(int id)
        {
            return View();
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(EmployeeViewModel employee)
        {
            try
            {
                HttpClient httpClient = _httpClientFactory.CreateClient();
                httpClient.BaseAddress = new Uri("https://localhost:7278/api/");
                var result = await httpClient.PostAsJsonAsync("employees", employee);
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index));
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        public async Task<IActionResult> Edit(int ID)
        {
            HttpClient httpClient = _httpClientFactory.CreateClient();
            httpClient.BaseAddress = new Uri("https://localhost:7278/api/");
            string uri = httpClient.BaseAddress.ToString() + $"employees/{ID}";
            var result = await httpClient.GetFromJsonAsync<EmployeeViewModel>(uri);
            return View(result);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, EmployeeViewModel employee)
        {
            try
            {
                // Check if the Employee ID Exist Already or not
                HttpClient httpClient = _httpClientFactory.CreateClient();
                httpClient.BaseAddress = new Uri("https://localhost:7278/api/");
                string uri = httpClient.BaseAddress.ToString() + $"employees/{employee.Portalid}";
                var employeeExist = await httpClient.GetFromJsonAsync<EmployeeViewModel>(uri);
                if (employeeExist != null)
                {
                    var result = await httpClient.PutAsJsonAsync(uri, employee);
                    if (result.IsSuccessStatusCode)
                    {
                        return RedirectToAction(nameof(Index));

                    }
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        public async Task<IActionResult> Delete(int id)
        {
            HttpClient httpClient = _httpClientFactory.CreateClient();
            httpClient.BaseAddress = new Uri("https://localhost:7278/api/");
            var result = await httpClient.GetFromJsonAsync<EmployeeViewModel>($"employees/{id}");
            return View(result);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, EmployeeViewModel employee)
        {
            try
            {
                // Check if the Employee ID Exist Already or not
                HttpClient httpClient = _httpClientFactory.CreateClient();
                httpClient.BaseAddress = new Uri("https://localhost:7278/api/");
                string uri = httpClient.BaseAddress.ToString() + $"employees/{id}";
                var employeeExist = await httpClient.GetFromJsonAsync<EmployeeViewModel>(uri);
                if (employeeExist != null)
                {
                    var result = await httpClient.DeleteAsync(uri);
                    if (result.IsSuccessStatusCode)
                    {
                        return RedirectToAction(nameof(Index));
                    }
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

    }
}
