﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeService.Models
{
    public class Employee
    {
        [Key]
        public int Portalid { get; set; }
        public string? Empname { get; set; }
        public string? Designation { get; set; }
        public int Grade { get; set; }
        public int DepId { get; set; }
        public string? Deptname { get; set; }
    }
}
