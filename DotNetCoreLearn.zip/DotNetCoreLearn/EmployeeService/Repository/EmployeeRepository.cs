﻿using EmployeeService.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeService.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly AppDbContext appDbContext;

        public EmployeeRepository(AppDbContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task<Employee> CreateEmployee(Employee employee)
        {

            var result = await this.appDbContext.AddAsync(employee);
            await this.appDbContext.SaveChangesAsync();
            return result.Entity;

        }

        public async Task DeleteEmployee(int id)
        {
            Employee? result = await this.appDbContext.Employees.FirstOrDefaultAsync(e => e.Portalid == id);
            if (result != null)
            {
                this.appDbContext.Remove(result);
                await this.appDbContext.SaveChangesAsync();
            }
        }

        public async Task<Employee> GetEmployeeById(int id)
        {
            Employee? result = await this.appDbContext.Employees.FirstOrDefaultAsync(e => e.Portalid == id);
            return result;
        }

        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            return await this.appDbContext.Employees.ToListAsync();
        }

        public async Task<Employee> UpdateEmployee(Employee employee)
        {
            // Find whether the employee exist or not
            var result = await this.appDbContext.Employees.FirstOrDefaultAsync(e => e.Portalid == employee.Portalid);
            if (result != null)
            {
                result.Empname = employee.Empname;
                result.Designation = employee.Designation;
                result.Grade = employee.Grade;
                result.DepId = employee.DepId;
                result.Deptname = employee.Deptname;
            }

            await this.appDbContext.SaveChangesAsync();
            return result;
        }
    }
}
