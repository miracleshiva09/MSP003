﻿using Microsoft.EntityFrameworkCore;

namespace API.Server.Models
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly AppDbContext appDbContext;

        public EmployeeRepository(AppDbContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task DeleteEmployee(int id)
        {
            Employee? result = await this.appDbContext.Employees.FirstOrDefaultAsync(e => e.ID == id);
            if(result != null)
            {
                this.appDbContext.Remove(result);
                await this.appDbContext.SaveChangesAsync();
            }
        }

        public async Task<Employee> GetEmployeeById(int id)
        {
            Employee? result = await this.appDbContext.Employees.FirstOrDefaultAsync(e => e.ID == id);
            return result;
        }

        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            return await this.appDbContext.Employees.ToListAsync();
        }
    }
}
