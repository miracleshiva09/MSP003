﻿namespace API.Server.Models
{
    public enum Gender
    {
        Male = 0,
        Female = 1,
        Other = 2
    }
}
