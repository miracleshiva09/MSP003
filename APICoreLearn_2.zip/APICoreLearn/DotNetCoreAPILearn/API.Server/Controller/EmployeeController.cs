﻿using API.Server.Models;
using Microsoft.AspNetCore.Mvc;

namespace API.Server.Controller
{
    [Route("api/employees")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeRepository employeeRepository;

        public EmployeeController(IEmployeeRepository employeeRepository)
        {
            this.employeeRepository = employeeRepository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Employee>>> GetAllEmployees()
        {
            try
            {
                return Ok(await this.employeeRepository.GetEmployees());
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in retrieving record from the database");
            }

        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Employee>> GetEmployeeByID(int id)
        {
            try
            {
                var result = await this.employeeRepository.GetEmployeeById(id);
                if (result == null)
                {
                    return NotFound();
                }
                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in retrieving record from the database");
            }
        }

        [HttpDelete("{id:int}")]
        public async Task<ActionResult> DeleteEmployee(int id)
        {
            try
            {
                var result = await this.employeeRepository.GetEmployeeById(id);
                if (result != null)
                {
                    await this.employeeRepository.DeleteEmployee(id);
                    return Ok(StatusCodes.Status200OK);
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in retrieving record from the database");
            }
        }

        [HttpPost]
        public async Task<ActionResult<Employee>> CreateEmployee(Employee employee)
        {
            try
            {
                if (employee == null)
                {
                    return BadRequest();
                }
                var createdEmployee = await this.employeeRepository.CreateEmployee(employee);
                return CreatedAtAction(nameof(employee), new { id = employee.ID }, createdEmployee);

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Creating a new employee");
            }
        }

        [HttpPut("{id:int}")]
        public async Task<ActionResult<Employee>> UpdateEmployee(int id, Employee employee)
        {
            try
            {
                var employeeToupdate = await this.employeeRepository.GetEmployeeById(id);
                if(employeeToupdate == null)
                {
                    return BadRequest($"Employee with the id - {id} is not found");
                }

                return await this.employeeRepository.UpdateEmployee(employee);

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in deleting the record from database");
            }
        }
    }
}
